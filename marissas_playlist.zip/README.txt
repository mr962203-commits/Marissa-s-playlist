Marissa's Playlist - Website
---------------------------
Files:
- index.html
- /images (contains 5 album cover images)

Quick publish to GitHub Pages (web UI):
1. Create a free GitHub account at https://github.com/ (choose a username like 'marissapage' or your real name).
2. Click the '+' icon → 'New repository'.
3. Name the repo (e.g., marissas-playlist). Make it Public. Click 'Create repository'.
4. Click 'Add file' → 'Upload files', then drag-and-drop the contents of this folder (index.html and the images folder).
5. Commit the upload.
6. In the repo go to Settings → Pages (or 'Pages' in the left sidebar), select the branch 'main' and folder '/' then Save.
7. After a minute or two, your site will be available at: https://<your-username>.github.io/<repo-name>/

If you'd like, I can also provide exact terminal git commands for uploading instead of the web UI.
